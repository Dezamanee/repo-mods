# Interesting Levels

Every R.E.P.O. map feels new. Levels get real layouts (winding halls, hubs, spirals), rooms with a purpose (vaults, loot rooms, monster nests, jackpots), risky shortcuts and the occasional wild twist. All of it is built around the valuables you actually have installed, including modded ones.

**Only the host needs this mod.** Everyone else just joins as usual: the host builds the map and the game sends it to all players, including late joiners. No feature needs other players to install anything.

<!-- Screenshot: a Monster Nest (monsters around a jackpot valuable) -->
<!-- Screenshot: a Domino Room (shelves full of fragile valuables) -->
<!-- Screenshot: a centerpiece room in the middle of a hub -->
<!-- Screenshot or GIF: the truck screen announcing a Wildcard level -->

## What it does

**Layouts**
- Maps come in different shapes: long and winding, a big central hub with spokes, compact and dense, or the game's own style.
- Many maps get a second route between areas, so you aren't always walking back the way you came.
- Rooms near the truck are calmer; rooms deep in are harder and hold better loot. Going deep is a choice.
- Extraction points are spread out, so they never all sit in one corner.
- No two maps in a row look alike. The mod remembers recent maps (even between sessions) and makes a different one.

**Special rooms**
- **Vault**: a hard-to-reach room with extra, valuable loot.
- **Hidden room**: tucked away off a side corridor, with a small bonus.
- **Hazard room**: the hardest version of a room, with valuable but fragile loot.
- **Quiet room**: a calmer room on the main route to regroup.

**Themed loot rooms**
- **Fragile Gallery**: only breakable, high-value valuables. Careful.
- **Heavy Storage**: only big and wide valuables. Bring the cart and a friend.
- **Junk Room**: lots of tiny, cheap valuables. Worth the time?

**Centerpiece rooms.** Some maps keep space for one of the level's big four-tile rooms in the middle of a hub or where routes meet.

**Risky shortcuts.** Some maps have two ways into the deep part: a short route through a chain of dangerous rooms, or a longer, calmer way round. The calm way matters when you're pushing a cart. Small maps get a small version: one dangerous room as the short way, with a normal route around it.

**About as much loot as the base game.** When the mod picks a different valuable than the game would have (pricier deep in, cheaper in a Junk Room), the level's loot budget is evened out to match, so a map has about as many valuables as the base game would give it. Features that add loot (vaults, bigger maps, Crowded, Scavenger Hunt, Junk Room, crazy rooms) share a cap: by default a level gets at most 30% more valuables than the base game would spawn there. Small or pricey levels still get a minimum per room. Gold Rush is the exception: fewer, pricier valuables on purpose.

**Easing in.** The first levels of a run stay calm: small maps get at most one themed or crazy room, and the crazy features below start on level 3 and get more common over the next few levels (with RepoRPG, over its chapters).

**Extraction pacing.** The haul goal is split unevenly: a small first extraction near the truck, bigger ones after, and a big final one deep in. The total stays the same.

**Crazy but fair** (rare, at most two per map, never on two maps in a row)
- **Monster Nest**: a deep room full of monsters guarding a jackpot valuable. They stay home until disturbed. Where the map allows, the nest has more than one way in, so you can lure them out or sneak past.
- **Domino Room**: shelves and tables stacked with fragile valuables. One bump, throw or monster can set off a chain reaction.
- **Explosive Pantry**: a room stocked with explosive valuables, with good loot next door. Never by the truck or an extraction point.
- **Jackpot**: one huge, fragile valuable deep in the map, worth a big part of the haul goal. Losing it hurts, but you can still make the goal without it.
- **Wildcard level**: two map modifiers at once, with bonus loot.
- **Stranded Start**: every extraction point is far from the truck. The first one is still a fair walk and asks for less.
- **Spiral**: the map winds inwards to a centre room with the best loot. Extraction points are on the outer rings, and one shortcut cuts between rings. Smaller maps get a short spiral: one loop around the centre room.
- **Escalating**: each extraction you complete brings another monster, and the first one wakes the nest. The last extraction is hard, but fair.

## Map modifiers

Rare, at most one per level (two on a Wildcard level). The truck screen tells everyone which one is active.

| Modifier | What it does |
|---|---|
| Sprawling | A bigger map with more loot. |
| Labyrinth | More loops and turns. |
| Treasure Pocket | There's a vault somewhere. |
| Gold Rush | Fewer valuables, all of them pricey. |
| Long Haul | Every extraction point is deep in the map. |
| Crowded | More monsters, more loot. |
| Scavenger Hunt | Tiny valuables tucked into hidden rooms and behind props. |

Wildcard levels only combine pairs that stay fair. For example, Crowded + Gold Rush or Long Haul + Labyrinth can happen, but Crowded + Long Haul can't.

## Works with your mods

- **Modded valuables**: valuables from any mod are found and used. Levels get extra spawn spots for sizes they're short of (big modded valuables often are). No single valuable mod can take over a map. Broken modded valuables are skipped instead of breaking the level.
- **Modded levels**: laid out like the game's own levels when they have the usual room types; otherwise left as their makers designed them. Custom level sizes work too.
- **RepoRPG**: works alongside it. Its difficulty presets, player scaling, valuable scaling, bosses and classes (including Scavenger and Appraiser) all apply as usual. The Jackpot is a wide or tall valuable whenever the level has one, so the Courier's Dispatch can't send it off.
- The haul goal is always checked against what players can actually reach, after every other mod has changed it.

## Settings

Settings are in `BepInEx/config/interestinglevels.repo.cfg`, or in game with a config menu mod such as REPOConfig. Only the host's settings matter.

Main switches (all on by default):
- Layout variety, special rooms, themed loot rooms, centerpiece rooms, risky shortcuts
- Map modifiers (and each modifier's weight), the truck screen message
- Extraction pacing (and how uneven it is)
- Each crazy feature, its chance, and the most crazy features per map
- Easing in: the first level with crazy features (3), how fast they ramp up, and the small-map size (under 8 rooms)
- Keeping maps full, the fewest valuables per room (also for Gold Rush), and the most valuables per level compared to the base game (1.3x)
- Clutter cleanup
- Tuning log (see below)

## Tuning log

The host writes one line per level to `BepInEx/config/InterestingLevels.tuning.jsonl`: the level, its size, features and modifiers, the valuables (count and value), the haul goal, whether it was completed, deaths and time taken. It stays on your computer; nothing is sent anywhere. The file is capped (512 KB by default; the older part is kept as `InterestingLevels.tuning.old.jsonl`), and you can turn it off with **Tuning log** under **8. Advanced**. If you'd like to help balance the mod, you can attach it to a bug report or suggestion.

## Compatibility notes

- **ExtractionGoalSetter**: extraction pacing turns itself off when it's installed, so the two never fight.
- **Other layout mods**: if another mod also changes the level layout, this mod keeps the game's layout (there's a setting for this).
- The map screen can't show the active modifier (each player's map is drawn on their own machine); the truck screen shows it instead.
- A level always loads. If anything goes wrong, that part is skipped for the level and the game's own behaviour fills in.

## Bug reports

Please report bugs at: [add your bug report link here]

Include:
- Your `BepInEx/LogOutput.log` (from the host, after the problem happened)
- The level name, and the seed if the log shows one (search the log for "seed")
- Your mod list (or your mod manager's profile code)

## Changelog

See the **Changelog** tab on this page.
