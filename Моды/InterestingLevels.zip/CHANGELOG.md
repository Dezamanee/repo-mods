# Changelog

## 1.4.3

### Fixed
- **Too many valuables on later levels** (for example 79 on level 9, where the base game spawns about 35-45). Three causes:
  - "Keep maps full" raised the loot budget for every pricey valuable, even ones the game itself would have picked, and never lowered it. Now it only evens out picks the mod changed, by the difference to the game's own pick for that spot, both ways (cheaper picks lower it), and by at most 25% of the level's budget.
  - The vault bonus was added to every size (up to +6 each) while the log said +6. It's now 6 in total, spread over the sizes the vault has spots for.
  - Loot features stacked without limit. Now every feature that adds loot shares one cap per level: by default at most 1.3x the base game's count for that level. Past it, each gets its share in proportion.
- The minimum valuables per room is now only a floor: it never adds past the cap.

### Changed
- Defaults: Wildcard loot bonus 1 (none), Scavenger Hunt weight 0.5, Junk Room weight 0.5 (lower until the new numbers are confirmed in play). Modifier and theme weights now accept decimals.
- New settings under 5. Valuables: "Most valuables vs. the base game" (1.3) and "Keep maps full: most budget change" (0.25).
- The debug log and the tuning log show the base game's count and budget for each level, the mod's count and value as a ratio to it, and what each feature asked for and got.

## 1.4.2

### Fixed
- Spiral maps no longer roll together with Long Haul (a spiral's extraction points are on its outer rings), and a Wildcard level never adds Long Haul to a spiral or a Stranded Start map.
- Stranded Start never puts an extraction point next to the truck's part of the map; if a map can't manage that, it's made without Stranded Start.
- Maps whose only way out is the truck (the smallest levels) no longer get extra rooms for a shortcut or spiral.
- A map that only fits the small shortcut no longer keeps the extra rooms meant for the full one.
- When the Modifiers or Special rooms step fails, Wildcard levels and the spiral's centre vault are skipped too, as intended.

## 1.4.1

### Added
- **Small shortcuts**: maps too small for a full risky shortcut can get a short one, a single dangerous room with a normal route around it.
- **Small spirals**: when a full spiral doesn't fit, the map can get a short one, a single loop around the centre room.
- **Tuning log**: one line per level in `BepInEx/config/InterestingLevels.tuning.jsonl` (stays on your computer, size-limited, can be turned off).

### Changed
- **Maps stay full of loot.** When the mod picks pricier valuables (deep rooms, vaults, hidden rooms, themed and crazy rooms), the level's loot budget grows to match, so maps get about as many valuables as the base game. With RepoRPG its value scaling still decides what everything is worth. Gold Rush still has fewer, pricier valuables. There's also a minimum number of valuables per room.
- **Calmer start to a run.** Small maps (under 8 rooms) get at most one themed or crazy room. The crazy features start on level 3 and get more common over the next levels; with RepoRPG, over its chapters. All of this can be changed in the settings.

### Fixed
- Early levels sometimes had very few valuables (for example 5 on level 1), because pricey picks used up the loot budget.

## 1.4.0

### Added
- **Crazy but fair features.** They're rare, at most two show up on one map, and none appears on two maps in a row.
  - **Monster Nest**: a deep room with extra monsters guarding a jackpot valuable. They stay home until someone comes close.
  - **Domino Room**: shelves and tables stacked with fragile valuables.
  - **Explosive Pantry**: a room full of explosive valuables, with good loot next door.
  - **Jackpot**: one huge, fragile valuable worth a big part of the haul goal. You can still make the goal without it.
  - **Wildcard level**: two map modifiers at once, with bonus loot.
  - **Stranded Start**: every extraction point is far from the truck; the first one asks for less.
  - **Spiral**: the map winds inwards to a centre room with the best loot, with one shortcut between rings.
  - **Escalating**: each completed extraction brings another monster and wakes the nest.
- Every new feature has its own on/off switch and chance in the settings.

### Changed
- New, clearer mod page and description.
- The valuable list is now prepared in the main menu, so the first level loads faster.
- The full valuable list goes to its own file instead of filling the log.

### Fixed
- A short freeze at the end of a level's loading while the map history was saved.

## 1.3.0

### Added
- **Themed loot rooms**: Fragile Gallery, Heavy Storage and Junk Room.
- **Extraction pacing**: a small first extraction, bigger ones after, the same total.
- **New map modifiers**: Gold Rush, Long Haul, Crowded and Scavenger Hunt.
- **Centerpiece rooms**: space for the level's big four-tile room in a spot that matters.
- **Risky shortcuts**: a short, dangerous way into the deep part, next to a longer, calmer way round.
- The active modifier is shown on the truck screen for everyone.

## 1.2.0

### Changed
- Much safer: if any part of the mod runs into a problem, only that part is skipped for the level and the level still loads.
- After a game update, only the parts that no longer fit turn off, with a notice for the host.
- The map history and settings files can't be damaged by a crash; a damaged file is set aside and rebuilt.

### Fixed
- Valuables were sometimes left out when their spawn spot was blocked.

## 1.1.0

### Added
- No repeated maps: a new map that looks too much like a recent one is remade, even across sessions.
- Recent layouts, modifiers, special rooms and start rooms are picked less often; repeated rooms are turned a different way.
- Rare surprises: a vault at the end of a long route, a grand hub, or a long drop.
- Clutter cleanup: no valuables in doorways, extraction areas or the truck area, nothing stuck or stacked, no overfull rooms.

## 1.0.0
- First release: map shapes, loops and side branches, special rooms (vault, hidden, hazard, quiet), better loot deeper in, spread-out extraction points, map modifiers (Sprawling, Labyrinth, Treasure Pocket), support for modded valuables, and a haul goal that always stays reachable.
