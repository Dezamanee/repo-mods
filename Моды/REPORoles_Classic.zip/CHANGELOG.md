### v3.0.2
- Fixed Engineer Role not working for clients.
- Balance change to Engineer, you'll give up 10 stamina and after 50 sec you'll regen 5 stamina

### v3.0.1
- Added Engineer Role

### v3.0.0
- Mod Compatibility with R.E.P.O `v0.4.x`

### v2.2.3
- Fixed a Networking crash when mod versions mismatch or other mods conflict.

### v2.2.2
- Added a config option for the **host** to disable REPO Roles upgrades (**client config is ignored!**)
- **If the host** disables the **Scout or Mage role**, their **respective upgrades will not spawn in the shop** (**client config is ignored!**)

### v2.2.1
- Updating the old Player Upgrade/Statsmanager Code - Thanks **Pxntxrez**
- Improve Compatibility with [REPOConomyPlus](https://thunderstore.io/c/repo/p/PxntxrezStudio/REPOConomyPlus/) mod! - Thanks again **Pxntxrez**
- Fix UI Scaling and Specifically fixing the Mage's Mana UI and Config Settings
> More Update coming soon-ish

### v2.2.0
- Mod Fixed for **REPO** `v0.3.0` and **REPOLib** version `3.0.x`

### v2.1.4
- Fixed Reaper Heal Buffs not working Client-Side/for non Host players
- Fixed Reaper Repetitively getting Health until the end of time xD

### v2.1.3
- Fixed `setReaperStatusRPC` Log Warning spam on level change

### v2.1.2
- Fixed a small issue causing Ranged Looter to not use the custom set description. - Thanks **Goldocelot**
- Fix Reaper causing lag and clean RPCs

### v2.1.1
- Fixed a small bug with the Mage Mana Regeneration
- Fixed Spelling in icon

### v2.1.0
- Mod Fixed for **REPO** `v0.2.1`