# Changelog

## 0.1.6

配置界面瘦身 + 回收位置判定重写。

### 配置项：两个开关合并为 `Only Sell At Intermission`

`Intermission Only (Strict)` 与 `Intermission Only` 是同一个问题的两半，叠加生效时还会互相打脸
（前者要求"只认中转站"，后者由 b5/b6 遗留的阶段白名单兜底）。0.1.6 合并为单一开关：

| | 开启（默认） | 关闭 |
|---|---|---|
| 时机 | 只在中转站（`Level - Lobby` 且本轮至少打完一关） | 除商店阶段以外任何时刻 |
| 位置 | 必须人在卡车内 | 必须人在卡车内 |

新键名 `Only Sell At Intermission`（分区 `General`），**默认值 `true` 继承自原 `Intermission Only`**，
即升级后行为与旧版默认配置一致。原两个键不再绑定，旧 `.cfg` 残留键被静默忽略（BepInEx 留作孤儿条目，
不报错）。

### 位置判定：从"物品在盒内"补上"人在车内"

0.1.5 及以前只校验手持物品是否落在车厢包围盒内（`Check Truck Box For Held`），从不校验玩家自身位置
——理论上站在车外门边、把手伸进车厢也能触发。0.1.6 显式加入位置闸门：

```
TimingAllowsSell()
  = OnlyIntermission ? OnlyIntermissionNow() : !IsShopStage()
IsLocalPlayerInTruck()
  = SemiFunc.PlayerGetLocal().RoomVolumeCheck.CurrentRooms 中存在 RoomVolume.Truck == true
```

`Check Truck Box For Held = true`（默认）时，在上述两项都通过后，再叠加原有的"手持物品在车厢包围盒内"
校验；改成 `false` 则只要求人在卡车内。房间判定不可用时按原有通道退化（`Max Truck Box Side` 过滤 +
`Truck Radius Fallback` 半径），不新增失败点。

### 移除的配置项（8 项）及理由

| 键 | 旧默认 | 理由 |
|---|---|---|
| `General.Only Sell Held Item` | true | 0.1.2 起恒为单件出售，false 分支无代码可达，死开关 |
| `General.Intermission Only (Strict)` | true | 语义合并进 `Only Sell At Intermission` |
| `General.Intermission Only` | true | 语义合并进 `Only Sell At Intermission`（新键继承其默认值） |
| `General.Allowed Stage` | `Lobby` | 阶段白名单被新开关完全取代，两开关并存会互相矛盾 |
| `General.Allowed Level Names` | 空 | 旧阶段逻辑的场景名白名单，新语义下只会放宽已禁止的场景 |
| `General.Must Be In Truck` | true | 仅服务已删除的"整车出售"路径；手持路径由 `Check Truck Box For Held` 负责 |
| `General.Block Props In Shop Stage` | true | 商店已被 `TimingAllowsSell()` 无条件拦截，此项永不生效 |
| `General.Confirm Before Sell` | false | 0.8 秒长按本身即确认动作，二次确认属冗余摩擦 |

保留全部 13 项有独立行为的配置：`Sell Key` / `Language` / `Hold To Sell Seconds` /
`Only Sell At Intermission` / `Check Truck Box For Held` / `Refund Percent` / `Truck Radius Fallback` /
`Max Truck Box Side` / `Sell Props` / `Show HUD` / `Debug Log` / `Allow Client Sell` / `Event Code`。

### 涉及的原版成员（改前已反编译确证）

| 成员 | 用于 |
|---|---|
| `PlayerAvatar.RoomVolumeCheck`（`RoomVolumeCheck` 字段） | 取玩家当前所处房间列表 |
| `RoomVolumeCheck.CurrentRooms`（`List<RoomVolume>`） | 逐房间判断 |
| `RoomVolume.Truck`（`bool`） | 车厢房间标识 |
| `PlayerAvatar.playerTransform` / `PlayerAvatar.instance` | 半径兜底的参考点 |
| `SemiFunc.PlayerGetLocal()` | 取本地玩家 |
| `SemiFunc.RunIsShop()` | 商店阶段拦截 |
| `SemiFunc.RunIsLobby()` / `RunManager.levelsCompleted` | 中转站判定（沿用 0.1.5 的"打完一关才算中转站"） |
| `SemiFunc.RunIsLevel()` | 关卡内识别 |
| `RunManager.levelIsShop` / `RunManager.instance` | 商店双保险 |

### 编译与核验

- 编译：Roslyn csc 单文件，引用 `REPO_Data\Managed` + `BepInEx\core`（剔除 `Mono.Cecil` / `0Harmony20` 冲突项）。
- `TruckSell.dll`：41,984 字节，MD5 `39D61A79197D56A37AC8A2AEF5C747D7`。
- Mono.Cecil 核验：本模组类型仅 `TruckSell.TruckSellPlugin`、`TruckSell.SoldLedgerPatch`；
  Assembly-CSharp 成员引用 73 条，**解析失败 0**；`ItemManager.GetPurchasedItems` 补丁目标解析 OK；
  0.1.6 已无旧配置键字符串残留。
- 未写入游戏安装目录任何文件。

## 0.1.5

修复老问题：**卖掉的物品，进入下一关又出现**。用户复现场景为「联机，房主与客机都装了本模组」。
反编译 `REPO_Data\Managed\Assembly-CSharp.dll` 后确认，这是两个独立缺陷叠加。

### 涉及的原版成员（反编译确证）

| 成员 | 角色 |
|---|---|
| `ItemManager.ItemsInitialize()` | 换关初始化入口，内部调用 `GetPurchasedItems()` |
| `ItemManager.GetPurchasedItems()`（private instance） | 按 `StatsManager.itemsPurchased` 重建 `purchasedItems` |
| `PunManager.TruckPopulateItemVolumes()` | 按 `purchasedItems` 在车厢 `ItemVolume` 重新 `Instantiate`（仅主机生成） |
| `StatsManager.itemsPurchased`（`Dictionary<string,int>`） | 购买记录的权威来源，key = `Item.name` |
| `StatsManager.item` / `itemStatBattery`（`Dictionary<string,...>`） | 实例名 → 道具映射，`ItemRemove` 的前置依赖 |
| `StatsManager.ItemRemove(string instanceName)` | 官方注销入口，`item` 里查不到实例名时 `Debug.LogError` 后直接返回，不扣计数 |
| `PhysGrabObject.DestroyPhysGrabObject()` | 原版唯一销毁入口（提取时逐件调用）：本端 `PhotonNetwork.Destroy`；非本端发起时 `RPC("DestroyPhysGrabObjectRPC", All)` 各端本地销毁 |
| `PhotonNetwork.Destroy` | 仅对本客户端 Photon 实例化的物体有效，场景物体（`ViewID != InstantiationId`）调用无效 |
| `SemiFunc.StatSyncAll()` → `PunManager.SyncAllDictionariesDelta()` → RPC `ReceiveSyncData` | 主机把字典变更同步给客机 |
| `ValuableDirector.valuableList` / `SetupHost()` | 战利品当关注册表与换关重建入口（战利品无跨关持久化） |

### 根因一：购买记录没被真正扣掉（所以下一关又生成）

0.1.4 的 `UnregisterPurchasedProp()` 有两个漏洞：

1. **把「没扣」当成了「扣了」**：`StatsManager.ItemRemove` 第一步要求 `StatsManager.item` 里存在该
   `instanceName`，否则只打 `Debug.LogError` 就返回；0.1.4 不看结果，只要调用不抛异常就置
   `official = true`。买来的道具被搬动后 `item` 里常常已经没有该条目，于是「成功注销」实为空操作。
2. **兜底被 `before > 0` 卡死**：兜底扣减读的是「猜出来的 key」的计数，一旦猜的 key 与权威 key
   （`Item.name`）不一致，`before == 0`，既不扣也不报错，静默放过。

结果：`itemsPurchased` 原封不动 → 换关 `GetPurchasedItems()` → `TruckPopulateItemVolumes()` 照旧生成。

### 根因二：卖掉的战利品从来没被销毁（双端都残留）

0.1.4 的 `DestroyValuable()` 走 `PhotonNetwork.Destroy`。关卡战利品是**场景物体**，
`photonView.ViewID != photonView.InstantiationId`，该调用静默失败：主机上的物体没消失，客机上的也没有，
玩家还能反复出售同一件（白刷钱）。

### 修复内容

```csharp
// 1) 销毁统一走原版入口（PhysGrabObject.DestroyPhysGrabObject）
private static bool DestroyByVanillaPath(GameObject go)
{
    PhysGrabObject pgo = go.GetComponent<PhysGrabObject>()
        ?? go.GetComponentInParent<PhysGrabObject>()
        ?? go.GetComponentInChildren<PhysGrabObject>();
    if (pgo == null || _mDestroyPGO == null) return false;
    object view = _fPGPhotonView.GetValue(pgo);   // photonView 为 internal，未挂网络时为 null
    if (view == null) return false;
    _mDestroyPGO.Invoke(pgo, null);               // 主机权威 + RPC All 同步
    return true;
}

// 2) 出售后按整表差异判断官方 ItemRemove 是否真的扣到，未扣则按权威 key 强制扣一次
Dictionary<string, int> snapshot = SnapshotPurchased(purchased);
_mItemRemove.Invoke(stats, new object[] { instanceName });
string changedKey = FindDecreasedKey(snapshot, purchased);
if (changedKey == null)
{
    string authoritative = FindPurchasedKeyByItem(ia, purchased); // itemDictionary 按 Item 引用反查
    int before = PurchasedGet(purchased, authoritative);
    if (before > 0) { PurchasedSet(purchased, authoritative, before - 1); changedKey = authoritative; }
}

// 3) Harmony 前缀：重建 purchasedItems 之前把台账写回字典，彻底拦住重生
[HarmonyPatch] // 实际以反射 Patch 挂载，补丁失败不影响其它功能
static void Prefix() { TruckSellPlugin.ApplySoldLedger("GetPurchasedItems"); }
```

- `UnregisterPurchasedProp()`：快照 + 全表差异校验 + `itemDictionary` 反查权威 key 强制扣减 +
  清理 `item` / `itemStatBattery` + 裁剪 `spawnedItems` / `purchasedItems`。
- 新增出售台账 `_soldLedger`（key → 应剩件数）与 `ApplySoldLedger()`：由 Harmony 前缀挂在
  `ItemManager.GetPurchasedItems()` 上，在列表重建前校正字典；`AbsorbLedgerPurchases()` 每 0.5 秒
  轮询，检测到重购即抬高应剩件数，避免误删新买的。
- 主机出售后调用 `SemiFunc.StatSyncAll()`，把 `itemsPurchased` / `item` / `itemStatBattery`
  同步给客机，避免客机拿着陈旧字典做判断。
- 战利品出售时从 `ValuableDirector.valuableList` 剔除，并按原版方式销毁（`DestroyPhysGrabObject`）。
- 客机侧逻辑不变：仍只发请求，不写任何权威状态，因此不会双扣、不会状态分叉。
- 版本号：`ModVersion` / `BuildTag` = `0.1.5`。

### 核验

- 单文件编译（csc，`/langversion:5`，仅 `src\TruckSellPlugin.cs`），产物 `TruckSell.dll`。
- Cecil 核验：类型仅 `TruckSell.TruckSellPlugin`（86 方法 / 80 字段）与 `TruckSell.SoldLedgerPatch`（1 方法），
  外来类型 0；引用 `Assembly-CSharp` 的 18 个类型、24 个成员签名，**MISSING 0**。
- 关键成员反编译比对：`GetPurchasedItems()`（nonpublic instance）、`DestroyPhysGrabObject()`（public instance）、
  `photonView`（nonpublic instance）、`ItemRemove(String)`、`itemsPurchased` / `item` / `itemDictionary`、
  `SemiFunc.StatSyncAll()`、`ValuableDirector.valuableList` 全部存在且签名一致。

### 需要实测的联机步骤

1. 主机与客机都装 `TruckSell.dll` 0.1.5，重启游戏，进同一房间。
2. 主机买 2 件同一道具（如手电），中转站里手持其中 1 件长按 G 卖掉，确认客机屏幕上也消失。
3. 走进下一关，检查车厢：应只剩 1 件；`BepInEx\LogOutput.log` 应出现
   `道具已注销 ... 官方ItemRemove=... 扣减key=... 剩余=1`。
4. 客机侧长按 G 请求出售，主机日志应有对应执行记录，且计数只减 1（不双扣）。
5. 卖出战利品（关卡战利品）验证：主机与客机上该物体都立即消失，且无法再被卖出。

## 0.1.4

修复 v0.1.3 发布包的**编译污染**：TruckSell.dll 里混进了 FogClear 0.3.0 的完整插件代码。

### 根因

v0.1.3 编译时用的是单条 csc 命令行，误把 FogClear 的源文件 `FogClearPlugin.cs` 与本模组的
`TruckSellPlugin.cs` **一起**传给了编译器，于是 FogClear 的全部类型被原样编译进 TruckSell.dll：

| 混入内容 | 具体表现 |
|---|---|
| 类型 | `FogClear.FogClearPlugin`（含 `FogLogic` / `FogParams` / `FogLogicPostfix`） |
| 插件标记 | `[BepInPlugin("com.fogclear.repo", "FogClear", "0.3.0")]` |
| 配置字段 | `farClipPlaneValue`、`lightDistanceValue`、`shadowDistanceValue`、`pixelLightCountTarget` 等 17 个 ConfigEntry |
| 日志文案 | `FogClear 0.3.0 已加载，去雾状态: ...` 等 18 处字符串字面量 |

后果：玩家只要装了 TruckSell 就等于同时装了 FogClear —— BepInEx 会注册两个同 GUID 插件、
两套配置项抢写同一个 cfg，并且两边的摄像机 farClip / 灯光距离逻辑同时生效，可能重复注册、
配置互相覆盖、性能异常。

### 修复

- 以**单文件**重新编译：csc 命令行只允许出现 `TruckSellPlugin.cs`，不得再混入任何其它模组源码。
- 在该文件头部注释中固化编译约束与本次事故说明，防止再次误传。
- 出厂 DLL 已双向核验：
  - `TruckSell.dll` 内只有 `TruckSell.TruckSellPlugin` 一个类型，无任何 FogClear 类型 / 字段 /
    字符串 / `com.fogclear.repo`；
  - 反向核验 `FogClear0.3.0.dll` 与 `FogClearPlugin.cs` 中不含任何 TruckSell 内容（未发生回向污染）。
- 公开 API 面未变：`TruckSellPlugin` 的方法数（74）与字段数（73）与 v0.1.3 完全一致，
  仅去掉了误入的 FogClear 类型，功能行为与 v0.1.3 相同。
- 体积由 56320 字节降为 40448 字节，被去掉的 15872 字节即 FogClear 的类型与元数据。

### 版本

- `BepInPlugin` 版本、`ModVersion`、`BuildTag`、`manifest.json`、README 统一为 **0.1.4**。

## 0.1.3

修复「在中转站卖掉的道具，进下一关又出现在车厢里」。

### 根因

出售道具（`ItemAttributes`，即商店买来的道具）时，v0.1.2 只做了 `PhotonNetwork.Destroy` 销毁场景物体，**没有注销购买记录**。而换关时的生成链路是：

```
ItemManager.ItemsInitialize()
  -> PunManager.TruckPopulateItemVolumes()
     -> 按 ItemManager.purchasedItems
        （由 StatsManager.GetPurchasedItems() 从 ItemsPurchased 字典重建）
        逐条 Instantiate 到车厢 ItemVolume
```

`ItemsPurchased` 字典的维护入口是 `StatsManager.ItemRemove(instanceName)`，售卖商店（`ItemBatteryRemove` / 官方出货）才会调用它。所以只销毁物体不减计数，下一关就会按记录原样重生，表现为「卖掉的物品还在」。战利品（`ValuableObject`）不受影响——车厢常驻不重载，其物体本就跨关保留。

### 修复

- 新增 `UnregisterPurchasedProp(ItemAttributes)`，在 `DestroyProp()` 销毁物体**之前**调用，严格按官方语义注销：
  1. 优先调用官方入口 `StatsManager.ItemRemove("<ItemName>/<n>")`（先从 `item` 字典确认该 instanceName 已注册），由游戏自身完成扣数与清理；
  2. 调用后回读 `ItemsPurchased` 校验，只有官方入口没真正扣掉时才自行 `-1`（计数减到 0 直接删键），**不会重复扣**；
  3. 同步清理 `StatsManager.item` / `itemStatBattery` 中残留的 instance 条目，以及 `ItemManager.spawnedItems`（被销毁实例）与 `purchasedItems`（对应 Item）列表条目；
  4. 仅在主机/单机（`SemiFunc.IsMasterClientOrSingleplayer()`）执行，客机走原有 RPC 请求路径，不重复注销。
- 键名解析 `ResolvePurchasedKey()` 按 `ItemsPurchased` 的真实写入键处理：优先 `itemAssetName` / GameObject 名 / `Item.itemName`，退回 `instanceName` 前缀；`instanceName` 与 key 不同名时也能正确命中。
- 每次注销输出一行 `TruckSell: 道具已注销 ... purchased X->Y` 日志，便于验证与排查。
- 反射字段全部按 `Instance|Public|NonPublic` 获取，游戏更新改名只会退化为跳过并告警，不会抛异常影响出售本体。

### 版本

- `BepInPlugin` 版本、`ModVersion`、`BuildTag`、`manifest.json` 统一为 **0.1.3**。

## 0.1.2

修复「出售不了」，并修改几个默认关闭项改为默认开启。

### 出售不了的真因

- **门禁自相矛盾**：`Allowed Stage` 默认 `Lobby`，其判定分支要求 `lobby && 中转态`；而 `Intermission Only (Strict)`
  只在更后面才作为额外条件生效。结果是即便把 Strict 关掉（界面显示为 false），`EvaluateStage()` 仍因"中转态"不成立而
  直接拒绝，表现为"选项明明关了，按 G 还是没反应"。现已改为 `lobby && (!strict || 中转态)`：关掉 Strict 就是
  "只要人在卡车场景就能卖"。
- **关卡进度字段成为硬门槛**：`RunManager.levelsCompleted` 读不到时（反射失败 / 游戏更新改字段名 / 值被重置）原先
  一律当作 0，等价于"永远是开局大厅"，中转站被永久拒绝。现在 `CompletedLevels()` 用 `-1` 表示读取失败，该情况下按
  中转站处理并放行，同时保留"上一场景是关卡"的兜底。
- 诊断文本新增 `strict=`、`done=-1` 语义，`[Sell]` 日志可直接区分"场景不对"与"中转态判定失败"。

### 默认值改为开启

| 配置项 | 旧默认 | 新默认 |
|---|---|---|
| `Check Truck Box For Held` | false | **true** |
| `Include Held Item` | false | **true** |
| `Sell Props` | false | **true** |
| `Confirm Before Sell` | false | **true**（仅兼容项，不参与判定） |
| `Truck Radius Fallback` | 0（关闭） | **20 米** |
| `Intermission Only (Strict)` | true | true（不变） |
| `Must Be In Truck` | true | true（不变） |

注意：BepInEx 对已存在的 `BepInEx\config\com.trucksell.repo.cfg` 不会覆盖旧值，要拿到新默认值需删除该文件或手动改键。

### 版本

- `BepInPlugin` 版本、`ModVersion`、`BuildTag`、`manifest.json` 统一为 **0.1.2**。

## 0.1.0

### 0.1.0 修订 b9（本次）

按第二轮反馈的细节修正：

- **读条改正为「短粗」**：上一版被误理解为整体缩小，实际是"长度变短、厚度和文字反而变大"。尺寸 190×6 → **160×14**，描边 1px → 2px，顶部高光 1px → 3px，标题字号 11 → **15 并加粗**，标题基线上移量 17px → 25px，位置仍为屏幕中央下方 70px。
- **`Max Items Per Sell` 默认 25 → 3**：单次出售数量硬上限默认收紧，防止判定异常时一次清空车厢；已存在的配置文件 `com.trucksell.repo.cfg` 同步由 25 改为 3（旧文件备份为 `.cfg.bak`）。填 0 表示不限制（不推荐）。
- **`Refund Percent` 默认 100 → 60**：回收价默认按物品当前价值的六折折算，改由 `CalcRefund()` 统一按 `price * percent / 100` 计算，范围 1~100。注意 BepInEx 只在键缺失时写入默认值，已存在 `com.trucksell.repo.cfg` 中的旧值不会自动变化，需手动改为 60 或删除该键让其重新生成。
- **icon.png 重绘**：REPO 卡车侧影 + 工业深色渐变背景，中部为绿色渐变的标准可回收标志（三箭头莫比乌斯环），底部为 `TruckSell` 字样，并加底部渐隐暗条保证文字清晰；输出 256×256 PNG。字形版本经用户确认为 C 案（Impact 粗体黄色字）。

### 0.1.0 修订 b8

按使用反馈做的三点打磨：

- **读条短小精致**：尺寸由 320×18 缩小到 190×6，位置保持不变（屏幕中央下方 70px）；改为 1px 深色描边 + 半透明底槽 + 金色填充 + 1px 顶部高光，文字降到 11 号并加 1px 阴影，不再压住准星附近画面。
- **语言可调**：新增 `General.Language`（默认 `Chinese`，可填 `Chinese` / `zh` / `中文` / `English` / `en`）。屏幕上所有文本（读条标题、手持提示、出售结果、拒绝原因）统一走 `L(zh, en)` 与 `ReasonText()`，日志与配置项名保持英文不受影响。启动日志新增 `TruckSell ui: language=... (zh=True/False)` 便于确认当前生效值。
- **文本只在中转站显示**：新增 `InSellStage()` 判定（与"能不能卖"同一套条件：`Allowed Stage` + `Intermission Only (Strict)`），`OnGUI` 进入即校验，不满足直接返回。关卡进行中、商店房、开局大厅不再出现任何 HUD 文本或读条，残留提示也不会跨场景留在屏幕上。

### 0.1.0 修订 b7（本次）

修复「b6 能卖，但把除手持以外的所有车内物品都卖了」，并按用户要求改为**长按出售手上那一件**：

- **出售范围收敛为单件**：只处理 `PhysGrabber.grabbedPhysGrabObject` 指向的那一件，车厢内其他物品一律不再纳入。旧的 `BuildSellPlan` / `HostSellAll` / `ClientRequestSellAll` 整车批量路径已整体删除。
- **长按读条（仿 CarryFriend）**：`Update` 中改为 `Input.GetKey` 轮询累计时长，满 `Hold To Sell Seconds`（默认 0.8s）才执行；`OnGUI` 用两张 1x1 Texture2D 画半透明底 + 填充条，上方显示 `Recycling <名称> (+$xx)`；中途松手、切换手持物、离开允许条件都会立即清零并取消。
- **新增 `General.Hold To Sell Seconds`**（默认 0.8，范围 0.1~5）。
- **新增 `General.Only Sell Held Item`**（默认 true）：设为 false 可回到旧的整车出售行为，仅供对照调试。
- **新增 `General.Intermission Only (Strict)`**（默认 true）：只允许在 `Level - Lobby` 且 `RunManager.levelsCompleted >= 1` 的中转站触发出售，开局大厅与关卡内按 G 完全不响应。
- **新增 `General.Check Truck Box For Held`**（默认 false）：true 时手持物品还必须落在车厢包围盒内才算可售；false 时只要人在中转站且手上有物品即可，避免站在车门口按了没反应。
- **默认值调整**：`Allowed Stage` 由 `Outro,Lobby` 改为 `Lobby`；`Sell Props` 保持 false（避免把手里的枪卖掉）；`Confirm Before Sell` 默认 false 且不再参与逻辑（被长按取代）。
- **主机端防改包**：`OnEvent` 收到长度 > 1 的 ViewID 请求直接拒绝，客机即使被改包也无法一次清算多件。
- **HUD**：平时在中转站手拿可售物时显示 `[G] Hold 0.8s to sell <名称> (+$xx)`；长按时切换为读条；条件不满足按下去会提示具体原因（Nothing in hand / Only works at intermission / Held prop blocked 等），并写入日志 `[Hold] 条件不满足：...`。
- 构建修复：源码文件必须保留 UTF-8 BOM，否则 csc 按本地代码页解析中文报 `CS1026` 假错误。

初始发布版本，后续所有修复与调整均在同一版号内迭代（未经用户许可不递增版本号）。

### 功能

- 在卡车车厢内按 **G**，一次性出售车内全部战利品与道具并立即获得现金。
- 主机 / 客机通用：客机按 G 通过 Photon 自定义事件请求主机，主机校验后加钱并同步销毁物品。
- 主机侧可开关 `Multiplayer.Allow Client Sell`，决定是否放行客机出售请求。

### 0.1.0 修订 b2（本次）

修复「按 G 只提示 Nothing in truck (39 found elsewhere)、什么也卖不掉」：

- **新增道具出售**。此前只卖 `ValuableObject`（地图上生成的战利品），而车里/商店买来的枪械、医疗包、弹药等是 `ItemAttributes`，一件都不会被收集。现在两类对象都出售，新增开关 `General.Sell Props`（默认开）。
- **车厢判定从"安全点 12m 球体"改为四重判定**：
  1. `RoomVolumeCheck.CurrentRooms` 含 `RoomVolume.Truck`；
  2. `RoomVolumeCheck.inTruck`（反射读取）；
  3. 位置落在 `RoomVolume.Truck` 全部 Collider 的合并包围盒内（0.6m 容差）；
  4. 前三条都拿不到时才退回 `TruckSafetySpawnPoint` 半径兜底（默认 12m）。
  旧版只有第 4 条，而 12m 球体中心在卡车安全点，车厢本身反而容易被判成"车外"。
- **手持物品永远不卖**：被 `PhysGrabber` 抓着的道具（正在用的枪、医疗包）一律跳过；战利品是否包含手持由 `Include Held Item` 决定。
- **新增 `General.Block Props In Shop Stage`**（默认开）：商店关卡不出售道具，避免把商店待结账商品直接卖成钱。
- **诊断日志大幅增强**：每次按 G 输出 `voTotal / voInTruck / propTotal / propInTruck / propInTruckPriced / truckBox 中心与尺寸 / 玩家坐标 / 玩家到安全点距离`，并逐条列出前 6 件战利品与前 6 件道具的 `value / inTruck / 坐标`，可直接对照是"收集不到"还是"判定被过滤"。
- **HUD 提示更具体**：区分"车内没有可卖物品"、"物品无价格"、"商店关卡禁售道具"三种情况。
- 修复 `RunManager.levelIsShop` 改为反射读取，避免不同游戏版本字段可见性差异导致加载失败。

### 0.1.0 修订 b4（本次）

**1. 修复「按一次 G 除手持物外全没了」——根因是车厢包围盒把多个 Truck 房间合并成一个总盒**

`RoomVolume.Truck` 在关卡里通常不止一个（卡车本体、起点停放区等）。旧版把所有 Truck 房间的 Collider `Encapsulate` 成一个大包围盒，只要地图上存在两个相距较远的 Truck 房间，这个总盒就会横跨整片地图，盒内一切都被判为"在车内"——于是一次按键就把地图上的战利品连同买来的装备一起销毁。

- 改为**逐房间独立包围盒**判定：任一个房间盒包含目标点才算车内，绝不合并。
- 新增**尺寸合理性过滤**：单个房间盒任一边超过 14m 直接弃用（车厢不可能这么大），并在日志中打印 `[Truck] 跳过尺寸异常的房间盒`。
- 距离兜底 `Truck Radius Fallback` **默认改为 0（关闭）**。12m 半径球会把车外一圈全算进车内，是误卖的第二大来源。

**2. 默认不再出售道具，手持物永不触碰**

- `Sell Props` 默认改为 **false**：枪械、医疗包、弹药、推车等 `ItemAttributes` 一律不动（旧版默认 true，会连同买来的装备一起清掉）。
- `Include Held Item` 默认改为 **false**：手上拿着的那件永远不卖。

**3. 三道保险，防止再出现一键清空**

| 保险 | 配置 | 默认 | 行为 |
| --- | --- | --- | --- |
| 阶段门禁 | `Allowed Stage` | `Outro` | 非允许阶段按键直接拒绝，只打日志不动物品 |
| 数量硬上限 | `Max Items Per Sell` | 25 | 候选超过上限整批拒绝，HUD 提示 `Too many (n>25) refused` |
| 二次确认 | `Confirm Before Sell` | true | 第一次按只打印清单与金额，5 秒内再按一次才真正出售 |

**4. 新增阶段限制：只在关卡与商店之间的"卡车准备中转阶段"可卖**

`SemiFunc` 阶段语义已用 Mono.Cecil 反编译 IL 逐一确证：

- `SemiFunc.RunIsLevel()` 为真 = 处于关卡场景（内部已排除 shop / lobby / menu / tutorial / arena）；
- `SemiFunc.RunIsShop()` 为真 = 商店房；
- `SemiFunc.RunIsLobby()` 为真 = 开局大厅；
- 中转阶段的判定：`RunIsLevel()` 为真 **且** `GameDirector.currentState ∈ {Outro, Result, End, EndWait}` 或 `GameDirector.LevelCompleted` 为真。

配置 `Allowed Stage` 支持多选逗号分隔：`Outro`、`Shop`、`Level`、`Lobby`、`Any`，默认 `Outro`（关卡打完后在卡车上准备、尚未进入商店的那段）。关卡进行中与商店房默认都卖不了。

**5. 中转阶段如果判定不中，可通过场景名白名单直接放行**

新增 `Allowed Level Names`（逗号分隔，按当前关卡场景名包含匹配）。每次按键日志都会打印：

`[Stage] level='场景名' prev='上一关场景名' state=当前GameDirector状态 completed=是否通关 shop=.. level=.. lobby=.. outro=..`

若默认 `Outro` 没覆盖到你那个中转房间，把日志里 `level='...'` 的场景名填进 `Allowed Level Names` 即可，无需重新编译。

**6. 金额作用域已确证：整局 run 内任何阶段都能改钱**

反编译 `PunManager.SetRunStatSet` 与 `StatsManager.GetRunStatCurrency`：

- 写入路径为 `StatsManager.runStats["currency"]`（字典，随 Photon 房间状态同步给全房间）；
- 该方法**只校验 `SemiFunc.IsMasterClientOrSingleplayer()`，没有任何关卡阶段守卫**；
- `runStats` 在整局 run 期间跨关卡持续存在，只有整局结束才重置。

结论：在中转房结算金额在机制上完全成立，不受所处关卡类型限制。

### 配置项

- `General.Sell Key`：出售按键，默认 `G`
- `General.Refund Percent`：按原价百分比计入，默认 100
- `General.Must Be In Truck`：是否要求物品在车厢内，默认 true（置 false 可全场景出售，用于快速验证模组是否生效）
- `General.Include Held Item`：手持战利品是否一并出售，默认 false（手持那件永远不卖）
- `General.Truck Radius Fallback`：距离兜底半径，默认 0（关闭）
- `General.Sell Props`：是否出售道具（ItemAttributes），默认 false
- `General.Block Props In Shop Stage`：商店关卡禁止出售道具，默认 true
- `General.Allowed Stage`：允许出售的阶段，默认 `Outro`（可多选：Outro/Shop/Level/Lobby/Any）
- `General.Allowed Level Names`：场景名白名单（逗号分隔，含匹配），默认空
- `General.Max Items Per Sell`：单次出售数量硬上限，默认 25，0 = 不限制
- `General.Show HUD`：屏幕底部提示，默认 true
- `General.Debug Log`：输出排查日志，默认 true
- `Multiplayer.Allow Client Sell`：是否允许客机发起出售，默认 true
- `Multiplayer.Event Code`：Photon 自定义事件码，默认 173（占用 173 与 174）

### 说明

- 不修改游戏文件，不使用 Harmony 改写原生逻辑。
- 编译产物与源码均只放在本文件夹，安装（复制到 `BepInEx\plugins`）由用户自行完成。
- 安装新 DLL 后需要完全退出游戏再启动，config 文件里新增的项会自动补齐。

### 0.1.0 修订 b5（本次）

**修复「中转房按 G 被拒绝，HUD/日志显示当前阶段不允许出售」——根因是中转房并不是 Level 场景的 Outro 态**

实测日志（关卡打完后回到卡车）：

```
[Stage] level='Level - Lobby' prev='Level - Arctic' state=Main completed=False shop=False level=False lobby=True outro=False
[Key] 拒绝：当前阶段不允许出售（allowed='outro' ... lobby=True outro=False ...）
```

即中转房本身就是 `Level - Lobby` 场景：`RunIsLobby()=true`、`RunIsLevel()=false`、`state=Main`、`LevelCompleted=False`，
所以旧的 `IsOutroStage()` 判定（要求 `RunIsLevel()` 为真且 `GameDirector.LevelCompleted` 或 Outro 系状态）永远不可能命中，
默认 `Allowed Stage = Outro` 也就永远拒绝。

- `Allowed Stage` 默认值由 `Outro` 改为 **`Outro,Lobby`**。
- 新增 `General.Intermission Only`（默认 **true**）：`Lobby` 阶段只在前一个场景是关卡场景时放行，
  避免把**开局大厅**（同样是 `Level - Lobby` 场景）也算成中转房。判据取 `RunManager.previousRunLevel`，
  上一个场景形如 `Level - Arctic` 即判定为中转；为空、菜单、大厅、教程场景一律不放行。
- 新增 `IsLobbyIntermission()`，阶段日志与诊断行追加 `intermission=` 字段，可直接看出门禁为何拒绝：
  `[Stage] level='...' prev='...' state=... lobby=... outro=... intermission=...`
- 拒绝提示改为明确指出中转房场景名与 `Intermission Only` 的用法，不再误导用户去填 `Allowed Level Names`。
- `Allowed Level Names` 白名单保留，仍是 `previousRunLevel` 取不到时的兜底手段（例如中途重连导致该字段丢失）。
- HUD 拒绝文案由 `Blocked in Main` 改为 `Blocked in <场景名>`，信息量更直接。
- 同步清理了 README / CHANGELOG 中的 AIGC 元数据块与"内容由AI生成"声明行；修正 README 编译说明
  （不能加 `/nostdlib+`，只需排除 `mscorlib.dll`，否则报 CS0518）。

### 0.1.0 修订 b6（本次）

修复 b5 之后「仍然卖不了」的两个独立问题：

**1. 阶段门禁：`previousRunLevel` 取不到（日志 `prev='-'`），中转房被误判为开局大厅**

游戏流程是 **关卡 → 商店 → 中转(卡车) → 关卡**，中转房的上一个场景其实是商店，而 `previousRunLevel` 在进入 Lobby 后可能已被清空，用"上一个场景名"判定的方案不可靠。

- 改用 `RunManager.levelsCompleted`（本轮已完成关卡数）作为主判据：中转时 `>= 1`，开局大厅为 `0`。
  日志会打印 `done=N`，可直接确认。
- `previousRunLevel` 的判定降级为兜底，仅在 `levelsCompleted` 反射取不到时使用。
- `Allowed Stage` 中的 `Outro` 关键字现在同时覆盖两种"中转"实现（关卡场景内的结算态 + Lobby 场景的中转房），
  旧配置 `Allowed Stage = Outro` 无需手改即可放行，避免"默认值更新但老 cfg 不生效"。
- 阶段日志追加 `done=` 字段。

**2. 车厢包围盒被尺寸阈值误杀（日志 `有效车厢房间盒数量=0`）**

b4 设定的单边 14m 上限把真实车厢盒（实测 `size=(14.15, 4.85, 5.72)`）直接丢掉，导致车厢判定恒为 0。

- 阈值改为可配置 `General.Max Truck Box Side`，默认 **20m**。
- 过滤日志追加 `limit=`，一眼能看出是阈值挡住还是真的没有 Truck 房间。
