# TruckSell — Hold-to-Sell Held Item at Intermission (REPO / BepInEx 5)

At the intermission — the stretch between levels when you are back in the truck — **hold G for 0.8 seconds
while carrying loot in your hands**, and the progress bar converts **that single item** into cash.
Release early and nothing happens. Nothing else in the truck is ever touched.

If you have any questions, please contact me ↓
Email: 670155978@qq.com
QQ: 670155978

- Version: 0.1.6
- Requires: BepInEx 5.4.x

# TruckSell — 中转站长按出售手持物品（REPO / BepInEx 5）
## What's new in 0.1.6

The config panel was overdue for a diet: two switches answered the same question, and the answer was always
"it depends". 0.1.6 collapses the timing question into **one** switch and makes the position requirement
explicit instead of implied.

- **`Intermission Only (Strict)` + `Intermission Only` → `Only Sell At Intermission`** (default `true`,
  inherited from the old `Intermission Only`). With it on you can only recycle **inside the truck at the
  intermission**; with it off you can recycle **inside the truck at any moment except the shop**.
- **Inside-the-truck is now an explicit gate.** Before, position was only checked as a bounding box around
  the held item (`Check Truck Box For Held`); the player's own position was not tested. Now
  `PlayerAvatar.RoomVolumeCheck.CurrentRooms` must contain the room whose `RoomVolume.Truck` is true, and only
  then does the held-item box check apply on top.
- **HUD follows the real gate.** The bar and hint are drawn only while a sale is actually possible
  (shop and outside-truck are dark).
- **8 redundant keys removed**: `Only Sell Held Item`, `Intermission Only (Strict)`, `Intermission Only`,
  `Allowed Stage`, `Allowed Level Names`, `Must Be In Truck`, `Block Props In Shop Stage`,
  `Confirm Before Sell`. Old leftovers in `com.trucksell.repo.cfg` are ignored silently — no errors, no
  behaviour change. Every key with real behaviour survives; see the removed-key table below for the per-key
  justification.

Detailed config mapping (old → new): see **Configuration (0.1.6 — 13 entries)** below.

## What's new in 0.1.5

- Fixed the old report that a sold item is **back again on the next level**, in the exact scenario
  "**multiplayer, host and clients both have the mod installed**". Two independent defects were behind it.

**Root cause 1 — the purchase record was never really decremented (props).**
`StatsManager.ItemRemove(instanceName)` starts by looking the instance up in `StatsManager.item` and
`Debug.LogError`+returns when it is missing — which happens all the time once a bought item has been moved
around — and 0.1.4 counted that call as a success (`official = true`). The fallback decrement was gated by
`purchased[guessedKey] > 0`, so whenever the guessed key differed from the authoritative key
(`Item.name`, e.g. `Item Gun` vs `Gun`) nothing was decremented and nothing was logged. On level transition
`ItemManager.ItemsInitialize()` -> `ItemManager.GetPurchasedItems()` -> `PunManager.TruckPopulateItemVolumes()`
then rebuilt the item from `StatsManager.itemsPurchased`, i.e. the sold prop was spawned again.

**Root cause 2 — sold loot was never destroyed (both ends kept it).**
0.1.4 destroyed loot with `PhotonNetwork.Destroy`. That call only works for objects this client instantiated
through Photon; level loot is a **scene** object (`ViewID != InstantiationId`), so it fails silently and the
object survives on the host **and** on every client — it could even be sold twice.

Fixes in 0.1.5:

| Area | Change |
|---|---|
| Purchase record | `UnregisterPurchasedProp()` snapshots `StatsManager.itemsPurchased`, calls the official `StatsManager.ItemRemove("<ItemName>/<n>")`, then detects the decrement by **diffing the whole map** instead of trusting the call. If the diff is empty it reverse-looks-up the authoritative key through `StatsManager.itemDictionary` (Item reference equality) and decrements once. `item` / `itemStatBattery`, `spawnedItems` / `purchasedItems` are pruned as before. |
| Sale ledger | Each sale records the "expected remaining count" for its key. A Harmony prefix on `ItemManager.GetPurchasedItems()` re-applies it right before the list is rebuilt, so a respawn is blocked even if something else touched the map later. Re-purchases are polled every 0.5 s and raise the expected count, so a newly bought copy is never eaten. |
| Destruction | Now goes through the vanilla path `PhysGrabObject.DestroyPhysGrabObject()`: host-authoritative `PhotonNetwork.Destroy` for Photon-instantiated props, `photonView.RPC("DestroyPhysGrabObjectRPC", RpcTarget.All)` for scene loot — the object disappears on host and clients alike. |
| Client state | After a host-side sale `SemiFunc.StatSyncAll()` (`PunManager.SyncAllDictionariesDelta()` -> RPC `ReceiveSyncData`) pushes the changed dictionaries to clients, so their `itemsPurchased` / `item` / `itemStatBattery` are no longer stale. |
| Loot registry | Sold loot is removed from `ValuableDirector.valuableList`. |
| Authority | Unchanged: clients only send the request through the existing event, all writes stay on the host, so there is no double charge and no client-side state divergence. |

Verified on the shipped DLL: 2 types only (`TruckSell.TruckSellPlugin`, `TruckSell.SoldLedgerPatch`), no foreign
type; 18 `Assembly-CSharp` types and 24 member signatures referenced, **0 unresolved**.

## What's new in 0.1.4

- **Fixed a build contamination in the 0.1.3 package.** The shipped `TruckSell.dll` had the whole
  FogClear 0.3.0 plugin compiled into it: a second `FogClear.FogClearPlugin` type with
  `[BepInPlugin("com.fogclear.repo", "FogClear", "0.3.0")]`, its `FogLogic` / `FogParams` /
  `FogLogicPostfix` members, 17 config entries (`farClipPlaneValue`, `lightDistanceValue`, ...) and
  18 log/description string literals. Installing TruckSell therefore also installed FogClear, which
  could lead to duplicate plugin registration, two config sets fighting over the same cfg file and
  two different camera farClip / light distance writers.
- Cause: the 0.1.3 build passed both `TruckSellPlugin.cs` **and** FogClear's `FogClearPlugin.cs` to csc.
- From 0.1.4 the mod is compiled from that single source file only, and the DLL is verified to contain
  `TruckSell.TruckSellPlugin` and nothing else — no FogClear type, field, string or GUID.
  The reverse check (`FogClear0.3.0.dll` for any TruckSell content) is clean as well.
- No functional change: the public surface of `TruckSellPlugin` (74 methods, 73 fields) is identical to
  0.1.3. DLL size drops from 56320 to 40448 bytes — that difference is the removed FogClear code.

## What's new in 0.1.3

- Fixed sold props coming back: a prop sold at the intermission **reappeared in the cargo bay on the next level**.
  Sale logic used to destroy the object only. On level transition `ItemManager.ItemsInitialize()` ->
  `PunManager.TruckPopulateItemVolumes()` re-instantiates everything listed in `ItemManager.purchasedItems`
  (rebuilt from the `ItemsPurchased` map), so an unregistered sale was simply respawned.
- `DestroyProp()` now calls `UnregisterPurchasedProp()` first: it invokes the official
  `StatsManager.ItemRemove("<ItemName>/<n>")` entry point, verifies the counter actually went down, falls back to a
  single manual decrement only when it did not, and prunes the leftover `item` / `itemStatBattery` instance entries
  plus the `spawnedItems` / `purchasedItems` list entries.
- Host / single-player only, clients still go through the existing request RPC, so nothing is deducted twice.
- One log line per sale: `TruckSell: 道具已注销 <name> | key=... | purchased X->Y`, handy for verification.
- Loot (`ValuableObject`) is unaffected: the truck scene is persistent across levels, its objects were never respawned.

## What's new in 0.1.2

- Fixed a gate bug: with `Intermission Only (Strict) = false`, the `Allowed Stage = Lobby` branch still demanded
  the intermission state and rejected every attempt. Disabling Strict now really means "anywhere in the truck scene".
- `RunManager.levelsCompleted` is no longer a hard requirement: if the field cannot be read (game update renamed it),
  the intermission is accepted instead of being treated as the starting lobby.
- Defaults flipped to ON: `Check Truck Box For Held`, `Sell Props`, `Include Held Item`, `Confirm Before Sell`,
  and `Truck Radius Fallback` is now 20 m instead of 0 (off).
- The existing `BepInEx\config\com.trucksell.repo.cfg` keeps its old values. Delete the file (or edit the keys by hand)
  to pick up the new defaults.

## Installation

1. Copy `TruckSell.dll` into `REPO\BepInEx\plugins\` (subfolders are fine).
2. Fully quit the game and restart it.
3. On first launch, `BepInEx\config\com.trucksell.repo.cfg` is generated.

## Usage

1. Finish a level and return to the truck at the intermission.
2. Grab the loot you want to sell and keep it in your hands.
3. **Hold G down.** A slim progress bar (160×14 px) and a short line `Recycling <name> (+$xx)` appear below the screen center.
4. After 0.8 s the item is sold automatically: you get paid and the object is destroyed. Release early and the hold is cancelled with no effect.

All of the following must be true to trigger a sale:

| Condition | Check | Message when it fails |
|---|---|---|
| Timing | `Only Sell At Intermission = true`: scene is `Level - Lobby` and `RunManager.levelsCompleted >= 1` (at least one level finished this run). `= false`: any moment except the shop stage | `Only works at intermission (done=0)` / `Blocked in shop stage` |
| You are inside the truck | `PlayerAvatar.RoomVolumeCheck` contains a `RoomVolume` with `Truck = true` (fallback: per-room truck bounds) | `Player not inside truck` |
| Holding something | `PhysGrabber.grabbedPhysGrabObject` is not null | `Nothing in hand` |
| Holding loot | Object has a `ValuableObject` with value > 0 | `Held item has no price` |
| Not holding a prop (default) | `ItemAttributes`-only objects require `Sell Props = true` | `Held prop blocked (Sell Props=false)` |

## Display rules

With `General.Show HUD` enabled, **every on-screen text and bar is drawn only when a sale is currently possible**.
Nothing is rendered inside the shop, or when you are outside the truck — the same `InSellStage()` gate used
for the sell check governs all UI, so stale prompts never linger after entering the shop or the next level.

## Behaviour changes (vs. b6)

| Item | b6 | b7 and later |
|---|---|---|
| Sell scope | All loot and props inside the truck | **Only the item in your hands** |
| Trigger | Single G press executes immediately (first press preview only) | **Hold G for 0.8 s**, executes when the bar fills |
| Intermission check | `Allowed Stage = Outro,Lobby` + `Intermission Only` | Since 0.1.6 a single **`Only Sell At Intermission`** switch |
| Mis-sell risk | Could empty the whole truck | Single item, requires a hold, releasing cancels |
| Language | English only | b8 `Language` switches Chinese / English |
| Text visibility | Shown in any scene | b8 shown only while a sale is possible |

## Configuration (0.1.6 — 13 entries)

| Key | Default | Description |
|---|---|---|
| `General.Sell Key` | `G` | Sell key |
| `General.Language` | `Chinese` | UI language: `Chinese` (or `zh`) = Chinese, `English` (or `en`) = English. Affects on-screen bar and messages only; log lines and config names stay English |
| `General.Hold To Sell Seconds` | 0.8 | Hold duration in seconds, 0.1–5 |
| `General.Only Sell At Intermission` | true | **The single timing switch (new in 0.1.6).** `true` = only at the intermission (truck scene between levels, at least one level finished this run). `false` = any moment except the shop. Both modes require you to stand inside the truck |
| `General.Check Truck Box For Held` | true | When true, the held item must also be inside the truck bounding box (default since 0.1.2). When false, being inside the truck with an item in hand is enough |
| `General.Refund Percent` | 60 | Cash paid as a percentage of the item value, 1–100 (60 = 60 % of value) |
| `General.Truck Radius Fallback` | 20 | Distance fallback radius (metres) used only when both the room check and the truck room scan fail. Not used in normal play |
| `General.Max Truck Box Side` | 20 | Max side length in metres for a truck room bounding box; larger boxes are discarded. The measured truck box is about 14.15 m |
| `General.Sell Props` | true | Also allow selling the held prop such as guns and medkits (default since 0.1.2; only the single held object is ever sold) |
| `General.Show HUD` | true | Bottom hint and progress bar |
| `General.Debug Log` | true | Write decision logs |
| `Multiplayer.Allow Client Sell` | true | Host-side switch: allow clients to sell (request is validated and executed by the host) |
| `Multiplayer.Event Code` | 173 | Photon event code, 100–198. The mod occupies `EventCode` and `EventCode + 1` |

### Removed keys in 0.1.6 (8 entries)

These keys are no longer bound. Leftovers in an old `.cfg` are ignored silently — BepInEx keeps them as
orphan entries, nothing errors, nothing breaks.

| Removed key | Old default | Why it was removed |
|---|---|---|
| `General.Only Sell Held Item` | true | Always true since 0.1.2 (single-item selling is the only path). A switch that cannot change behaviour is dead weight |
| `General.Intermission Only (Strict)` | true | **Merged** into `Only Sell At Intermission`; it was the second half of the same question |
| `General.Intermission Only` | true | **Merged** into `Only Sell At Intermission`; its default (`true`) is what the new switch inherits |
| `General.Allowed Stage` | `Lobby` | Fully superseded by `Only Sell At Intermission`; keeping both meant two switches could contradict each other |
| `General.Allowed Level Names` | empty | Scene-name whitelist for the legacy stage logic; with the new switch it could only ever re-allow what the switch forbids |
| `General.Must Be In Truck` | true | Only governed the removed whole-truck path; the held-item path uses `Check Truck Box For Held` |
| `General.Block Props In Shop Stage` | true | The shop is now blocked unconditionally before this check could matter (moved into the timing gate) |
| `General.Confirm Before Sell` | false | The 0.8 s hold-to-sell gesture already is the confirmation; a second prompt on top of it was pure friction |

Nothing with independent behaviour was dropped: sell key, hold time, refund rate, prop policy, truck detection
tuning, HUD, language, multiplayer switches and debug logging are all still there.

Note: source files must be saved as UTF-8 with BOM. Otherwise csc parses the Chinese string literals with the
local code page and reports bogus errors such as `CS1026 ) expected`.

---

# TruckSell — 中转站长按出售手持物品（REPO / BepInEx 5）

在中转站（关卡之间回到卡车的那一段）里，**手上拿着战利品**时长按 **G** 0.8 秒，
读条走完会把**手上这一件**换成现金。松开即取消，不会碰车厢里其他任何东西。

如有任何问题，请与我联系 ↓
邮箱：670155978@qq.com
QQ：670155978

- 版本：0.1.6
- 依赖：BepInEx 5.4.x

## 0.1.6 更新内容

配置界面该瘦身了：两个开关在回答同一个问题，而且答案永远是"看情况"。0.1.6 把"时机"收敛成
**一个**开关，并把"位置"要求从隐含变成显式。

- **`Intermission Only (Strict)` + `Intermission Only` → `Only Sell At Intermission`**（默认 `true`，
  继承自旧的 `Intermission Only`）。开启时只能**在中转站、且人在卡车内**回收；关闭时除商店以外、
  **任何时刻只要在卡车内**都可以回收。
- **"人在卡车内"成为独立闸门。** 以前只校验手持物品是否落在包围盒内（`Check Truck Box For Held`），
  从不校验玩家自身位置。现在要求 `PlayerAvatar.RoomVolumeCheck.CurrentRooms` 中存在
  `RoomVolume.Truck == true` 的房间，再叠加手持物品包围盒校验。
- **HUD 跟随真实判定。** 读条与提示只在"当前确实可以出售"时绘制（商店房、车外均为空白）。
- **移除 8 个冗余键**：`Only Sell Held Item`、`Intermission Only (Strict)`、`Intermission Only`、
  `Allowed Stage`、`Allowed Level Names`、`Must Be In Truck`、`Block Props In Shop Stage`、
  `Confirm Before Sell`。旧 `com.trucksell.repo.cfg` 里的残留键会被静默忽略——不报错、不改变行为。
  所有具备独立功能的键全部保留，逐条理由见下方"移除的旧配置项"表。

新旧配置项完整对照：见下方 **配置项（0.1.6 共 13 项）**。


## 0.1.5 更新内容

- 修复老问题：**卖掉的物品，进入下一关又出现**，且正是「联机、房主和客机都装了本模组」这个场景。
  背后其实是两个互不相干的缺陷。

**根因一：购买记录根本没被扣掉（道具）。**
`StatsManager.ItemRemove(instanceName)` 第一步是去 `StatsManager.item` 里找该实例名，找不到就直接
`Debug.LogError` 返回 —— 而买来的道具一旦被搬来搬去，`item` 里往往已经没有该条目 —— 0.1.4 却把这次
「什么也没扣」的调用当成了成功（`official = true`）；兜底扣减又被 `purchased[猜测key] > 0` 挡住，
一旦猜出来的 key 与权威 key（`Item.name`，例如 `Item Gun` 与 `Gun` 不同名）不一致，就既不扣也不报错。
换关时 `ItemManager.ItemsInitialize()` → `ItemManager.GetPurchasedItems()` → `PunManager.TruckPopulateItemVolumes()`
照样按 `StatsManager.itemsPurchased` 把道具实例化回车厢，于是卖掉的又回来了。

**根因二：卖掉的战利品从来没被真正销毁（双端都留着）。**
0.1.4 用 `PhotonNetwork.Destroy` 销毁战利品。这个接口只对**本客户端通过 Photon 实例化**的物体有效，
而关卡战利品是**场景物体**（`ViewID != InstantiationId`），调用只会静默失败，物体在主机和客机上都还在，
甚至能被反复出售。

0.1.5 的改动：

| 环节 | 改动 |
|---|---|
| 购买记录 | `UnregisterPurchasedProp()` 先给 `StatsManager.itemsPurchased` 拍快照，再调官方 `StatsManager.ItemRemove("<ItemName>/<n>")`，然后**用整表差异**判断到底有没有扣成功，不再相信调用本身。差异为空时，通过 `StatsManager.itemDictionary`（按 `Item` 引用比对）反查权威 key 强制扣一次；`item` / `itemStatBattery`、`spawnedItems` / `purchasedItems` 照旧清理。 |
| 出售台账 | 每次出售都记录该 key 的「应剩件数」。Harmony 前缀挂在 `ItemManager.GetPurchasedItems()` 上，在重建列表之前把台账写回字典，即便后面有别处动过字典也能拦住重生；每 0.5 秒轮询一次重购，买到同一件时抬高「应剩件数」，不会误删新买的。 |
| 销毁方式 | 改走原版唯一入口 `PhysGrabObject.DestroyPhysGrabObject()`：Photon 实例化的道具由主机 `PhotonNetwork.Destroy`，场景战利品走 `photonView.RPC("DestroyPhysGrabObjectRPC", RpcTarget.All)`，主机与客机同步消失。 |
| 客机状态 | 主机出售后调用 `SemiFunc.StatSyncAll()`（`PunManager.SyncAllDictionariesDelta()` → RPC `ReceiveSyncData`）把变更后的字典推给客机，客机的 `itemsPurchased` / `item` / `itemStatBattery` 不再陈旧。 |
| 战利品登记表 | 卖掉的战利品从 `ValuableDirector.valuableList` 中剔除。 |
| 权威归属 | 不变：客机依旧只发请求，所有写操作留在主机，不存在双扣与状态不一致。 |

出厂 DLL 已核验：只有 2 个类型（`TruckSell.TruckSellPlugin`、`TruckSell.SoldLedgerPatch`），无外来类型；
引用 `Assembly-CSharp` 的 18 个类型、24 个成员签名，**解析失败 0 个**。

## 0.1.4 更新内容

- **修复 0.1.3 发布包的编译污染**：出厂 `TruckSell.dll` 里被编译进了一整个 FogClear 0.3.0 插件 ——
  多出一个 `FogClear.FogClearPlugin` 类型（带 `[BepInPlugin("com.fogclear.repo", "FogClear", "0.3.0")]`、
  `FogLogic` / `FogParams` / `FogLogicPostfix`、17 个配置项如 `farClipPlaneValue`、`lightDistanceValue`、
  18 处日志文案）。装 TruckSell 等于同时装了去雾，会出现重复注册插件、两套配置抢写同一个 cfg、
  两边同时改摄像机 farClip 与灯光距离的问题。
- 根因：0.1.3 编译时把 `TruckSellPlugin.cs` 和 FogClear 的 `FogClearPlugin.cs` **一起**传给了 csc。
- 0.1.4 起只按单文件编译，并已核验 DLL 内只有 `TruckSell.TruckSellPlugin`，无任何 FogClear 类型 /
  字段 / 字符串 / GUID；反向检查 `FogClear0.3.0.dll` 也不含 TruckSell 内容。
- 功能无变化：`TruckSellPlugin` 的公开面与 0.1.3 完全一致（74 个方法、73 个字段）。DLL 由 56320 字节
  降到 40448 字节，减少部分即被清掉的 FogClear 代码。

## 0.1.3 更新内容

- 修复「中转站卖掉的道具，下一关又出现在车厢」。旧逻辑只销毁物体，没注销购买记录；换关时
  `ItemManager.ItemsInitialize()` → `PunManager.TruckPopulateItemVolumes()` 会按 `ItemsPurchased`
  里的记录把道具重新实例化到车厢，于是卖掉的又被生成回来。
- `DestroyProp()` 销毁前先调 `UnregisterPurchasedProp()`：走官方 `StatsManager.ItemRemove("<ItemName>/<n>")`，
  调用后回读计数校验，没扣成功才自行扣一次（不会重复扣），并清理 `item` / `itemStatBattery` 残留条目
  与 `spawnedItems` / `purchasedItems` 列表项。
- 只在主机/单机执行，客机仍走原有请求 RPC，不会双扣。
- 每次出售打印一行 `TruckSell: 道具已注销 <名称> | purchased X->Y` 日志，便于验证。
- 战利品（`ValuableObject`）不受影响：车厢场景跨关常驻，其物体本来就不会重生。

## 0.1.2 更新内容

- 修复门禁漏洞：`Intermission Only (Strict) = false` 时，`Allowed Stage = Lobby` 分支仍在强行要求"中转态"，
  导致关闭 Strict 依旧全部拒绝。现在关闭 Strict 就是"卡车场景内任意时刻"都放行。
- `RunManager.levelsCompleted` 不再是硬性条件：字段读不到时（例如游戏更新改了字段名）按中转处理，
  不再一律当成开局大厅拒掉。
- 默认值改为开启：`Check Truck Box For Held`、`Sell Props`、`Include Held Item`、`Confirm Before Sell`，
  `Truck Radius Fallback` 由 0（关闭）改为 20 米。
- 已存在的 `BepInEx\config\com.trucksell.repo.cfg` 会保留旧值，需删除该文件（或手动改键值）才能拿到新默认值。

## 安装

1. 把 `TruckSell.dll` 复制到 `REPO\BepInEx\plugins\`（可放在子文件夹里）。
2. 完全退出游戏后重新启动。
3. 首次启动会在 `BepInEx\config\com.trucksell.repo.cfg` 生成配置。

## 使用

1. 打完一关，回到中转站的卡车里。
2. 用手把想卖的战利品抓起来（保持在手上）。
3. **按住 G 不放**，屏幕中央下方出现一条短粗读条（160×14 px）与一行小字 `回收 <物品名> (+$xx)`。
4. 读条满 0.8 秒即自动出售，加钱并销毁该物品；中途松手则取消，什么都不发生。

允许触发的前提（全部满足）：

| 条件 | 判据 | 不满足时的提示 |
|---|---|---|
| 时机 | `Only Sell At Intermission = true`：场景为 `Level - Lobby` 且 `RunManager.levelsCompleted >= 1`（本轮至少打完一关）；`= false`：除商店阶段以外的任何时刻 | `Only works at intermission (done=0)` / `Blocked in shop stage` |
| 人在卡车内 | `PlayerAvatar.RoomVolumeCheck` 的房间列表里存在 `RoomVolume` 且其 `Truck = true`（房间判定不可用时退化为逐房间包围盒） | `Player not inside truck` |
| 手上有东西 | `PhysGrabber.grabbedPhysGrabObject` 非空 | `Nothing in hand` |
| 手上是战利品 | 物体含 `ValuableObject` 且价值 > 0 | `Held item has no price` |
| 手上不是道具（默认） | 若只含 `ItemAttributes`，需要 `Sell Props = true` 才放行 | `Held prop blocked (Sell Props=false)` |

## 显示规则

`General.Show HUD` 为 true 时，**所有屏幕文本都只在"当前确实可以出售"时出现**：
处于商店房、或人不在卡车内，一律不绘制任何提示与读条（判定由 `InSellStage()` 统一把关，
条件与"能不能卖"完全一致）。因此中途进商店或下一关，残留提示不会留在屏幕上。

## 行为变化（相对 b6）

| 项 | b6 | b7 及之后 |
|---|---|---|
| 出售范围 | 车厢内全部战利品 + 道具 | **只卖手上那一件** |
| 触发方式 | 按一下 G 立即执行（首次仅预览） | **长按 G 0.8 秒**读条完成才执行 |
| 中转站判定 | `Allowed Stage = Outro,Lobby` + `Intermission Only` | 0.1.6 起收敛为单一开关 `Only Sell At Intermission` |
| 误卖风险 | 会清空整车 | 单件、需长按、松手即取消 |
| 语言 | 仅英文 | b8 起 `Language` 可切中文 / 英文 |
| 文本显示范围 | 任意场景都会提示 | b8 起只在可出售时显示 |

## 配置项（0.1.6 共 13 项）

| 配置 | 默认 | 说明 |
|---|---|---|
| `General.Sell Key` | `G` | 出售按键 |
| `General.Language` | `Chinese` | 界面语言：`Chinese`（或 `zh`、`中文`）= 中文；`English`（或 `en`）= 英文。只影响屏幕上的读条与提示文字，日志与配置项名不受影响 |
| `General.Hold To Sell Seconds` | 0.8 | 长按判定时长（秒），0.1~5 |
| `General.Only Sell At Intermission` | true | **0.1.6 新增的唯一时机开关**。`true` = 只在中转站（关卡之间的卡车场景、且本轮至少打完一关）可回收；`false` = 除商店阶段以外，任何时刻只要在卡车内即可回收。两种模式下都要求在卡车内 |
| `General.Check Truck Box For Held` | true | true 时手上物品还必须落在车厢包围盒内才算可售（0.1.2 起默认开启）；false 时只要人在卡车内且手上有物品即可 |
| `General.Refund Percent` | 60 | 按价值的百分比折算现金，1~100（60 即按六折回收） |
| `General.Truck Radius Fallback` | 20 | 距离兜底半径（米），仅在房间判定与车厢房间扫描同时失败时启用，正常游玩不会触发 |
| `General.Max Truck Box Side` | 20 | 车厢房间包围盒单边上限（米），超过则弃用该房间盒。实测车厢约 14.15m |
| `General.Sell Props` | true | 手上拿的是道具（枪械、医疗包等）时是否也允许出售（0.1.2 起默认开启，永远只卖手上那一件） |
| `General.Show HUD` | true | 底部提示与读条显示 |
| `General.Debug Log` | true | 输出判定日志 |
| `Multiplayer.Allow Client Sell` | true | 主机端开关：true = 允许客机按 G 出售（请求由主机校验并执行）；false = 仅主机可出售 |
| `Multiplayer.Event Code` | 173 | Photon 事件码，100~198。本模组占用 `EventCode` 与 `EventCode + 1` |

### 0.1.6 移除的旧配置项（8 项）

以下键不再绑定。旧 `.cfg` 里的残留键会被静默忽略——BepInEx 会把它们留成孤儿条目，不报错、不影响功能。

| 被移除的键 | 旧默认值 | 移除理由 |
|---|---|---|
| `General.Only Sell Held Item` | true | 0.1.2 起恒为单件出售，改 false 也无代码路径可走，属无法改变行为的死开关 |
| `General.Intermission Only (Strict)` | true | 与 `Only Sell At Intermission` 是同一个问题的两半，**语义合并**进新开关 |
| `General.Intermission Only` | true | 同样合并进新开关；新开关的默认值 `true` 即继承自它 |
| `General.Allowed Stage` | `Lobby` | 阶段白名单被新开关完全取代；两个开关同时存在会出现"互相打架"的配置 |
| `General.Allowed Level Names` | 空 | 旧阶段逻辑的场景名白名单；新语义下它只可能放宽新开关已禁止的场景，故移除 |
| `General.Must Be In Truck` | true | 仅作用于已移除的"整车出售"路径；手持路径由 `Check Truck Box For Held` 负责 |
| `General.Block Props In Shop Stage` | true | 商店阶段已在时机判定里被无条件拦截，此项永远轮不到生效 |
| `General.Confirm Before Sell` | false | 0.8 秒长按本身就是确认动作，再叠一层二次确认纯属多余摩擦 |

所有具有独立功能的项均保留：出售按键、长按时长、回收折扣、道具策略、车厢判定微调、HUD、语言、
联机开关与调试日志一个未删。

注意：源文件必须带 UTF-8 BOM，否则 csc 按本地代码页解析中文字符串会报
`CS1026 应输入 )` 之类的假错误。
