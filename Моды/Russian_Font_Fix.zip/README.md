# Russian Font Fix

Fixes Cyrillic text rendering in the official Russian translation of R.E.P.O. and aligns upgrade names with their counters.
