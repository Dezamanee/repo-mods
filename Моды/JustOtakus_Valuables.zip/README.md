# Details
Adds a lot of custom new valuables and items to the game.
Some even have new unique functions!

Compatible with REPO v0.5

A list of all valuables and items with their references can be found on the mod page wiki:
https://thunderstore.io/c/repo/p/JustOtaku/JustOtakus_Valuables/wiki/

Mod Creation and Scripting by JustOtaku:
https://www.youtube.com/@JustOtakuGame

Models made by DatCookie:
https://www.youtube.com/@DatCookie
