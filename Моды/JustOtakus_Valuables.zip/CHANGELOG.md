# Changelog

## Version 0.3.0

- updated item compatibility to REPO v0.5
- changed colors of the multiplying mine item
- added new sounds to the pokeball valuable

## Version 0.2.1

- updated item compatibility to REPO v0.4
- changed particles of "JustOtaku Plush" and "Cookie Plush" valuables

## Version 0.2.0

- added Keyblade Valuable
- added Ralf Schumacher Valuable
- added Minecraft FNAF Pizzeria Valuable
- updated Minimaru Valuable
- updated Bormp Valuable
- fixed Multiplying Mine Item

## Version 0.1.10

- fixed Giga Stonks Valuable Wrong Settings
- fixed JustOtaku_Statue Valuable Light Bug
- fixed Tiny Car Valuable Audio Error
- fixed Yamato Valuable Exctraction Point Hit Box Bug

## Version 0.1.9

- updated item compatibility to REPO v0.3
- disabled Multiplying Mine Item (fixed in next update)

## Version 0.1.8

- added Multiplying Mine Item

## Version 0.1.7

- updated item compatibility to REPO v0.2

## Version 0.1.6

- added Tiny Generator Valuable
- added movement to Minimaru when his button is pushed

## Version 0.1.5

- added a button to Minimaru to start its animation (will get a custom feature in a later update)
- made the animations of Fan, Minimaru and Netzteil smoother

## Version 0.1.4

- fixed Bonk Bat and Hero Bat throwing a lot of errors (cause was the custom battery bars feature in the beta, which is not supported in the normal release) 

## Version 0.1.3

- added Peetopia Valuable 
- added JustOtaku Statue Valuable 
- added script for Banan
- added script for Cookie Plush
- added more lines to the JustOtaku Plush Script
- changed script of Bormp explosion (explosion can now trigger random)

## Version 0.1.2

- added functionality to the JustOtaku Plush

## Version 0.1.1

- added Valuable Car functionality to the Tiny Car 

## Version 0.1.0

Added Valuables:
- Clodsire Plush (Pokemon)
- Fazwatch (FNAF)
- Pog Bottom (The Binding of Isaac)
- Horse Conch (Meme)
- Metal Pipe (Meme)
- Ferg (Meme)
- Stonks (Meme)
- Giga Stonks (Meme)
- Bormp (Meme)
- Minimaru (Danganronpa)
- Yamato (Devil May Cry)
- Cookie Plush (DatCookie)
- JustOtaku Plush (JustOtaku)
- JustOtaku Head (JustOtaku)
- Tiny Car (Meme)
- Netzteil (Meme)
- Cisco Business CBS250-8T-D_valuable (Meme)
- Banan (Meme)
- Fan (FNAF)
- Cream Puff (Mashle)
- Pokeball (Pokemon)
- Clowm Horn (LC + Meme)

Added Shop Items:
- Hero Bat (Yakuza / Like a Dragon)
- Bonk Bat (Yakuza / Like a Dragon)