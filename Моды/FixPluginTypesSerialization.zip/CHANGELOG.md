# 1.1.2

Updated preconfigured offsets (6000.3.17f1) for countries that are blocked by Unity's symbol servers.

# 1.1.1

I LOVE GEOPOLITICS YAAAAY

Added preconfigured offsets for if the Unity Symbol Servers aren't reachable (for example because some very lovely North American country has blocked you)

# 1.1.0

Updated to latest version of [FixPluginTypesSerialization](https://github.com/xiaoxiao921/FixPluginTypesSerialization) to account for potential Unity version upgrades

# 1.0.0

Initial release
