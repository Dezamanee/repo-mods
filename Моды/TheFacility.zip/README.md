# The Facility

### Created by **grey5525** *(hann.o)* ♥ they/them

---

### Acknowledgements

Thank you so much to these beautiful lads for all the support :)

**DragonKing**, **Rogue**, **SammyCadian**, **Rosé**

All custom assets and textures are made by me using Unity and Krita | NO AI

---

## Rooms

| Room Type         | Count |
|-------------------|:-----:|
| Start Rooms       |   5   |
| Normal Modules    |   12  |
| Passage Modules   |   6   |
| Dead-End Modules  |   8   |
| Extraction Module |   9   |
| Total             |   40  |

---

## Valuables
- Origami Paper Crane | Tiny
- Green Binder | Small
- Clipboard | Small
- Semibot Head | Medium
- Wet Floor Sign | Medium
- Truck Tire | Tall
- Water Dispenser | Very Tall
- Wooden Pallette | Wide
---

## Screenshots

<p align="center">
  <img src="https://i.postimg.cc/RZYbXcjm/Screenshot_1.jpg"/>
</p>

<p align="center">
  <img src="https://i.postimg.cc/W1yfXMQv/Screenshot_2.jpg"/>
</p>

<p align="center">
  <img src="https://i.postimg.cc/cLz5XQPF/Screenshot_3.jpg"/>
</p>

<p align="center">
  <img src="https://i.postimg.cc/pLS1qD30/Screenshot_4.jpg"/>
</p>

<p align="center">
  <img src="https://i.postimg.cc/T3sHCrB7/Screenshot_5.jpg"/>
</p>

<p align="center">
  <img src="https://i.postimg.cc/4x0FBzj2/Screenshot_6.jpg"/>
</p>

<p align="center">
  <img src="https://i.postimg.cc/cC7Vzrff/Valuables.jpg"/>
</p>

---
