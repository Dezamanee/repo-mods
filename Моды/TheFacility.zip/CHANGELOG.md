# The Facility

* ### Version 1.1.7
* Fixed overlapping ceiling in "Gated" Extraction
* Fixed blue screen material

* ### Version 1.1.6
* Fixed friggin truck localization

* ### Version 1.1.5
* Fixed being unable to Open Extractions
* Fixed "Observation" Normal (Diff 2) Vending Machine Glass
* Fixed Red Extraction box
* Fixed Z-Fighting for "Attic" Normal (Diff 2)
* Added Valuables under "Stage" Dead-End (Diff 2)
* Fixed "Gated" Extraction Length
* Fixed Healer lid in "Truck" Dead-End (Diff 2)
* Updated ReadMe
* Changed NavMesh in "Truck" Dead-End (Diff 2) to Not Walkable
* ### Known Issues
* Monsters still can't climb ladders

* ### Version 1.1.4
* Removed "Basement Exit" Dead-End (Diff 2)
* Removed "Loading Station" Dead-End (Diff 2)
* Added "Truck" Dead-End (Diff 2)
* Added "Stage" Dead-End (Diff 2)
* Fixed Loading Graphics
* Fixed Medium Health Pack Desync
* Fixed Valuables
* Fixed Pipe Positions
* Added Kill Box to "Cubby" Passage (Diff 3)
* Fixed "Broken Wall" Collision
* Removed "Money" Manor Valuable (Until futher notice)
* Made some Vending Machines have broken glass
* ### Known Issues
* Decorative Semibots Missing (WIP)
* Some Monsters can't climb Ladders

* ### Version 1.1.3
* Performance improvements (?)
* Removed extraction level points

* ### Version 1.1.2
* Actually fixed pipe collision
* Fixed empty health props desync

* ### Version 1.1.1
* Fixed ceiling tile blocking money bag in extraction
* Fixed pipe having incorrect hitbox

* ### Version 1.1.0
* Added 4 Difficulty 2 Modules
* Added 2 Difficulty 3 Modules

* ### Version 1.0.9
* Added 5 Difficulty 2 Modules
* Added 8 Difficulty 3 Modules
* Added more props
* Enabled Modded Valuables

* ### Version 1.0.8
* Added more decoration and props
* Changed semibot prop lighting
* Removed bathroom module
* Fixed valuable spawn in a starting room

* ### Version 1.0.7
* Actually fixed the valuables this time
* Fixed box blocking doorway in the Office Module
* Fixed missing colliders on semibots

* ### Version 1.0.6
* Removed giant red extraction box
* Fixed desynced valuables
* Added a few new props
* Fixed toilet mesh

* ### Version 1.0.5
* Complete Asset Remake again :)
* Working for the new Monster Update
* Only includes Difficulty 1 Modules
* Includes 9 Custom Valuables

### Version 1.0.4

* Added 4 Difficulty 2 Modules
* Fixed Extractions
* Fixed Red Extraction Box
* Changed lighting again (lag ;-;)

### Version 1.0.3

* Reworked all assets
* Remade all rooms
* Added 5 new custom valuables

### Version 1.0.2

* Removed "Walkway" Room due to bugs
* Changed lighting
* Added more valuable spawn spots
* Added loading graphics
* Fixed valuable presets
* Added ambience/music presets

### Version 1.0.1

* Uploaded the actual level file..



### Version 1.0.0

* Release
* I forgot to add the level...
