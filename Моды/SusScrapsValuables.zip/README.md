# Sus's Scraps!

Adds 87 Valuables from games such as Warframe, Resident Evil, Dark Souls/Elden Ring, Destiny, Modded Minecraft, Legos, Valorant, League of Legends, Half Life, Helldivers and More!

![Valuables](https://i.imgur.com/Hzg6CH5.png)
![1.0.5 update](https://i.imgur.com/sXOoa32.png)


## Valuables
- Archon Shard (Warframe)
- Corpus Locker (Warframe)
- Hobbled Dragon Key (Warframe)
- Ordis (Warframe)
- Orokin Cell (Warframe)
- Orokin Container (Warframe)
- Sprodling (Warframe)
- Warframe Mod (Warframe)
- One Thousand Voices (Destiny)
- Ghost (Destiny)
- Sparrow (Destiny)
    - Drivable, scuffed.
- Vi Gauntlet (League of Legends/Valorant)
    - Handle with Care!
- The Spike (Valorant)
- Skye Hawk (Valorant)
- Soul of Cinder's Gauntlet (Dark Souls)
- Soul of Cinder's Head (Dark Souls)
- Soul of Cinder's Sword (Dark Souls)
- Soul of Cinder's Magic Staff (Dark Souls) 
    - Fires a beam of magic when struck
- Mushroom Person (Dark Souls)
- Knight Helmet (Dark Souls)
- Malenia's Helmet (Elden Ring)
- Hunter's Hat (Bloodborne)
- d20 (DnD)
- Tofu (Resident Evil)
- 9mm ammo (Resident Evil)
- Umbrella Key Card (Resident Evil)
- Licker Head (Resident Evil)
- Diamond Key (Resident Evil)
- Heart Key (Resident Evil)
- Club Key (Resident Evil)
- Spade Key (Resident Evil)
- Fox Head (Minecraft)
- MekaHelmet (Minecraft, Mekanisms Mod)
- MekaChestplate (Minecraft, Mekanisms Mod)
- MekaLeggings (Minecraft, Mekanisms Mod)
- MekaBoots (Minecraft, Mekanisms Mod)
- MekaTool (Minecraft, Mekanisms Mod)
- Chi (Lego)
- Minikit (Lego)
- Red Power Brick (Lego)
- Golden Brick (Lego)
- Samsung Galaxy 3 (Samsung)
- iPhone 4 (Apple)
- Lethal Company Helmet (Lethal Company)
- Dripped out Crewmate (Among Us, Kinda)
- Resin (Half Life)
- Resin (Half Life)
- Resin (Half Life)
- Stack of Resin (Half Life)
- Sprite Cranberry (The Coca-Cola Company)
- Chainsaw (Chainsaw Man)
    - Handle with Care!
- Tougher Times (Risk of Rain 2)
- Cow Figure (A Sus original)
- Beeper (A Sus original)
    - It flies
- Wendy's Milky Shake (A Sus original)

## 1.0.5 update
- Maruchan Ramen 
	-chicken
	- beef
	- chili
	- roast beef
	- pork
	- soy sauce
	- creamy chicken
	- cup-o-noodles
	- full cup-o-noodles
- Blahaj (Ikea) 
	- One small, one big
- Pumpkin (Warframe)
- Hiveworm (Destiny 2)
- Molly/M.U.L.E (Deep Rock Galactic)
- Lootbug (Deep Rock Galactic)
- Bugdiver (Helldivers 2)
- Hellpod (Helldivers 2)
- Intelpad (Helldivers 2)
- Stim (Helldivers 2)
- Stratagem (Helldivers 2)
- Kunai (Warframe)
- Kuva (Warframe)
- Wrench (Minecraft, Create Mod)
- Cogwheel (Minecraft, Create Mod)
- Arcane Pedelstal (Minecraft, Ars Nouveau Mod)
- Backpack (Minecraft, Sophisticated Backpacks Mod)
- Controller (Minecraft, Refined Storage Mod)
- Chest (Minecraft, Lootr Mod)
- Waystone (Minecraft, Waystone Mod)
- WD40





