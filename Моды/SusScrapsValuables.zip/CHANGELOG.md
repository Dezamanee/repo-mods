#### 1.0.5: 
##### Added
##### - Maruchan Ramen chicken
##### - Maruchan Ramen beef
##### - Maruchan Ramen chili
##### - Maruchan Ramen roast beef
##### - Maruchan Ramen pork
##### - Maruchan Ramen soy sauce
##### - Maruchan Ramen creamy chicken
##### - Maruchan Ramen cup-o-noodles
##### - Maruchan Ramen full cup-o-noodles
##### - 2 Blahaj (Ikea) 
##### - Pumpkin (Warframe)
##### - Hiveworm (Destiny 2)
##### - Molly/M.U.L.E (Deep Rock Galactic)
##### - Lootbug (Deep Rock Galactic)
##### - Bugdiver (Helldivers 2)
##### - Hellpod (Helldivers 2)
##### - Intelpad (Helldivers 2)
##### - Stim (Helldivers 2)
##### - Stratagem (Helldivers 2)
##### - Kunai (Warframe)
##### - Kuva (Warframe)
##### - Wrench (Minecraft, Create Mod)
##### - Cogwheel (Minecraft, Create Mod)
##### - Arcane Pedelstal (Minecraft, Ars Nouveau Mod)
##### - Backpack (Minecraft, Sophisticated Backpacks Mod)
##### - Controller (Minecraft, Refined Storage Mod)
##### - Chest (Minecraft, Lootr Mod)
##### - Waystone (Minecraft, Waystone Mod)
##### - WD40
#### 1.0.6: 
##### - Forgot to add CHANGELOG.md
#### 1.0.7: 
##### - And I messed up the images, fixes


#### 1.0.4: 
##### - Minor Fixes

#### 1.0.3: 
##### - Release










