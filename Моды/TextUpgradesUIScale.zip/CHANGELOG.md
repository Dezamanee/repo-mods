# Changelog

## 1.4.1

- Updated for R.E.P.O. v0.5.0.
- The list now shrinks only as far as it has to, instead of by how many upgrades you have, so a short list stays readable.
- Each upgrade's level is drawn next to its name, so the columns no longer drift apart with Russian names. Can be turned off with `AlignColumns`.

## 1.2.1

- Updated the README preview image to use the raw GitHub image URL.
- Set the default `ShrinkStep` to `0.07`.

## 1.2.0

- Added a BepInEx config file for scaling behavior and text layout.
- Added configurable step-based text shrinking.
- Added configurable line spacing.
- Added optional width-based shrinking for long upgrade names.
- Renamed the BepInEx config to `DarkSpider90.TextUpgradesUIScale.cfg`.

## 1.1.0

- Updated for R.E.P.O. v0.4.0.
- Kept default text size for 10 or fewer active upgrades.
- Restored gradual percentage-based scaling after 10 upgrades.
- Disabled wrapping only when scaling is needed.

## 1.0.0

- Initial release.
